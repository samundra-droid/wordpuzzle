package com.example.Word.Puzzle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordPuzzleApplicationTests {

	@Test
	void contextLoads() {
	}

}
