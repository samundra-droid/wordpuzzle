package com.example.Word.Puzzle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordGuessGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordGuessGameApplication.class, args);
	}

}